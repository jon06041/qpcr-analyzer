import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score

def sigmoid(x, L, k, x0, B):
    '''Sigmoid function for qPCR amplification curves'''
    return L / (1 + np.exp(-k * (x - x0))) + B

def analyze_curve_quality(cycles, rfu, plot=False):
    '''Analyze if a curve matches S-shaped pattern and return quality metrics'''
    try:
        # Initial parameter guesses
        L_guess = max(rfu) - min(rfu)  # Amplitude
        k_guess = 0.5  # Steepness
        x0_guess = cycles[len(cycles)//2]  # Midpoint
        B_guess = min(rfu)  # Baseline
        
        # Fit sigmoid
        popt, pcov = curve_fit(sigmoid, cycles, rfu, 
                              p0=[L_guess, k_guess, x0_guess, B_guess],
                              maxfev=2000)
        
        # Calculate fit quality
        fit_rfu = sigmoid(cycles, *popt)
        r2 = r2_score(rfu, fit_rfu)
        
        # Calculate residuals
        residuals = rfu - fit_rfu
        rmse = np.sqrt(np.mean(residuals**2))
        
        # Extract parameters
        L, k, x0, B = popt
        
        # Quality criteria for S-curve identification
        criteria = {
            'r2_score': r2,
            'rmse': rmse,
            'amplitude': L,
            'steepness': k,
            'midpoint': x0,
            'baseline': B,
            'is_good_scurve': (r2 > 0.95 and k > 0.1 and L > 100),
            'fit_parameters': popt,
            'parameter_errors': np.sqrt(np.diag(pcov))
        }
        
        if plot:
            plt.figure(figsize=(10, 6))
            plt.plot(cycles, rfu, 'bo', label='Data', markersize=4)
            plt.plot(cycles, fit_rfu, 'r-', label='Sigmoid Fit (R²={:.3f})'.format(r2), linewidth=2)
            plt.xlabel('Cycle')
            plt.ylabel('RFU')
            plt.legend()
            plt.title('qPCR Amplification Curve Analysis\nGood S-curve: {}'.format(criteria['is_good_scurve']))
            plt.grid(True, alpha=0.3)
            plt.show()
        
        return criteria
        
    except Exception as e:
        return {'error': str(e), 'is_good_scurve': False}

def batch_analyze_wells(data_dict):
    '''Analyze multiple wells/samples for S-curve patterns'''
    results = {}
    good_curves = []
    
    for well_id, data in data_dict.items():
        cycles = data['cycles']
        rfu = data['rfu']
        
        analysis = analyze_curve_quality(cycles, rfu)
        results[well_id] = analysis
        
        if analysis.get('is_good_scurve', False):
            good_curves.append(well_id)
    
    return results, good_curves

def detect_curve_anomalies(cycles, rfu):
    '''Detect common qPCR curve problems'''
    anomalies = []
    
    # Check for plateau curves (no exponential phase)
    if max(rfu) - min(rfu) < 100:  # Low amplitude
        anomalies.append('low_amplitude')
    
    # Check for early plateau
    mid_point = len(rfu) // 2
    if np.std(rfu[mid_point:]) < 50:  # Early plateau
        anomalies.append('early_plateau')
    
    # Check for irregular baseline
    baseline_cycles = cycles[:10]  # First 10 cycles
    baseline_rfu = rfu[:10]
    if np.std(baseline_rfu) > 100:
        anomalies.append('unstable_baseline')
    
    # Check for negative amplification
    if np.any(np.diff(rfu[10:20]) < -50):  # Decrease in exponential phase
        anomalies.append('negative_amplification')
    
    return anomalies

def load_cfx_data(filename):
    '''Load CFX Manager exported CSV data'''
    import pandas as pd
    
    try:
        # Read CSV file
        df = pd.read_csv(filename)
        
        # Assume first column is cycles
        cycles = df.iloc[:, 0].values
        
        # Extract well data (all columns except first)
        well_data = {}
        for col in df.columns[1:]:
            well_data[col] = {
                'cycles': cycles,
                'rfu': df[col].values
            }
        
        return well_data
        
    except Exception as e:
        print('Error loading CFX data: {}'.format(e))
        return None

def main():
    '''Main function to run the analysis'''
    # Example with test data
    cycles = np.array(range(1, 41))
    rfu = np.array([100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100])
    
    print('=== qPCR S-Curve Analysis ===')
    
    # Analyze the curve
    results = analyze_curve_quality(cycles, rfu, plot=True)
    
    if 'error' in results:
        print('Error: {}'.format(results['error']))
        return
    
    print('\nCurve Analysis Results:')
    print('R² Score: {:.4f}'.format(results['r2_score']))
    print('RMSE: {:.2f}'.format(results['rmse']))
    print('Is Good S-curve: {}'.format(results['is_good_scurve']))
    print('Amplitude (L): {:.2f}'.format(results['amplitude']))
    print('Steepness (k): {:.4f}'.format(results['steepness']))
    print('Midpoint (x0): {:.2f}'.format(results['midpoint']))
    print('Baseline (B): {:.2f}'.format(results['baseline']))
    
    # Check for anomalies
    anomalies = detect_curve_anomalies(cycles, rfu)
    if anomalies:
        print('\nDetected anomalies: {}'.format(', '.join(anomalies)))
    else:
        print('\nNo anomalies detected')

# Run the analysis directly
main()

