# qPCR S-Curve Analyzer

A web-based tool for analyzing qPCR (quantitative PCR) amplification curves. Upload CFX Manager CSV files to get detailed S-curve analysis with quality metrics and interactive visualizations.

## Features

- **File Upload**: Drag-and-drop or browse to upload CFX Manager CSV files
- **Smart Analysis**: Sigmoid curve fitting with quality metrics (R², RMSE, curve parameters)
- **Interactive Charts**: View individual well curves with detailed parameters
- **Flexible Cycles**: Supports variable cycle counts (30, 35, 38, 40, 45+ cycles)
- **Quality Assessment**: Automatic detection of good S-shaped curves vs. anomalies
- **Local History**: Browser-based storage of analysis results
- **Export Results**: Download analysis results as CSV

## Quick Start

### For Laboratory Use

1. Export your qPCR data from CFX Manager as CSV format
   - Include all wells and cycle data in the export
   - Make sure "Cycle" column is included

2. Upload the CSV file to the analyzer
3. View results with interactive charts and quality metrics
4. Export results for further analysis

### Supported Data Formats

- CFX Manager CSV exports
- Variable cycle counts (tested with 30-45 cycles)
- 96-well and 384-well plate formats

## Deployment

### Railway/Heroku Deployment

1. Connect your GitHub repository to Railway or Heroku
2. The app will automatically detect Python and install dependencies
3. Uses the simplified `simple_app.py` for reliable deployment without database dependencies

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python simple_app.py
```

The app will be available at `http://localhost:5000`

## Technical Details

- **Backend**: Flask with NumPy/SciPy for curve fitting
- **Frontend**: Vanilla JavaScript with Chart.js for visualization
- **Analysis**: Sigmoid function fitting with adaptive parameter estimation
- **Storage**: Local browser storage (no database required)

## File Structure

```
├── simple_app.py          # Main Flask application (simplified)
├── app.py                 # Full Flask application (with database)
├── qpcr_analyzer.py       # Core analysis engine
├── models.py              # Database models (for full version)
├── static/
│   ├── script.js          # Frontend JavaScript
│   └── style.css          # Styling
├── index.html             # Main interface
├── requirements.txt       # Python dependencies
├── Procfile              # Railway/Heroku deployment config
└── runtime.txt           # Python version specification
```

## Analysis Metrics

For each well, the analyzer provides:

- **Quality Score**: R² correlation coefficient
- **Curve Parameters**: Amplitude, steepness, midpoint, baseline
- **Error Metrics**: RMSE and parameter uncertainties
- **Anomaly Detection**: Identifies common qPCR problems

## Browser Compatibility

- Modern browsers with JavaScript enabled
- Chrome, Firefox, Safari, Edge
- Local storage support required for history feature

## Support

This tool is designed for laboratory teams using CFX Manager qPCR data. The simplified version ensures reliable deployment without complex database setup while maintaining full analysis capabilities.