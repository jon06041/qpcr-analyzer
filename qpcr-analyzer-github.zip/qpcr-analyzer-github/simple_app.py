from flask import Flask, request, jsonify, send_from_directory
import json
import os

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "qpcr_analyzer_secret_key_2025"

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/analyze', methods=['POST'])
def analyze_data():
    """Endpoint to analyze qPCR data"""
    try:
        # Import the analyzer here to ensure NumPy is loaded in the right environment
        from qpcr_analyzer import process_csv_data, validate_csv_structure
        
        # Get JSON data from request
        data = request.get_json()
        filename = request.headers.get('X-Filename', 'unknown.csv')
        
        if not data:
            return jsonify({'error': 'No data provided', 'success': False}), 400
        
        # Validate data structure
        errors, warnings = validate_csv_structure(data)
        
        if errors:
            return jsonify({
                'error': 'Data validation failed',
                'validation_errors': errors,
                'validation_warnings': warnings,
                'success': False
            }), 400
        
        # Process the data
        results = process_csv_data(data)
        
        if not results.get('success', False):
            return jsonify(results), 500
        
        # Include validation warnings in successful response
        if warnings:
            results['validation_warnings'] = warnings
        
        return jsonify(results)
        
    except ImportError as e:
        return jsonify({
            'error': f'NumPy/SciPy dependencies not available: {str(e)}',
            'success': False
        }), 500
    except Exception as e:
        return jsonify({
            'error': f'Server error: {str(e)}',
            'success': False
        }), 500

@app.route('/sessions', methods=['GET'])
def get_sessions():
    """Get all analysis sessions - simplified version without database"""
    return jsonify({
        'sessions': [],
        'total': 0,
        'message': 'Database functionality temporarily disabled - results will not be saved'
    })

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        # Test if scientific libraries are available
        import numpy as np
        import scipy
        scientific_libs = f"NumPy {np.__version__}, SciPy {scipy.__version__}"
    except ImportError:
        scientific_libs = "Not available"
    
    return jsonify({
        'status': 'healthy',
        'message': 'qPCR S-Curve Analyzer',
        'version': '2.1.0-simplified',
        'scientific_libraries': scientific_libs
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Ensure static directory exists
    if not os.path.exists('static'):
        os.makedirs('static')
    
    print("Starting qPCR S-Curve Analyzer...")
    print(f"Flask app running on http://0.0.0.0:5000")
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)